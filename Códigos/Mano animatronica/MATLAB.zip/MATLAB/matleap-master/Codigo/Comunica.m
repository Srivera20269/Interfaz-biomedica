
MUNE_EXT = 0;
MATRIZ_DATA = [255,127+MUNE_EXT,127+MUNE_EXT,127+MUNE_EXT];

 
s = serial('COM3');
fopen(s);
fprintf(s,MATRIZ_DATA);


%SE DESCONECTA DEL OBJETO
fclose(s);
%BORRA TODOS LOS OBJETOS
delete(s);
clear s